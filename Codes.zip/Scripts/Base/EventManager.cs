using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//空的包装接口

public interface IEventInfo{}

//事件信息类

public class EventInfo : IEventInfo
{
    public UnityAction actions;
}

//重载泛型事件信息类

public class EventInfo<T> : IEventInfo
{
    public UnityAction<T> actions;
}

//双泛型类

public class EventInfo<T,K> : IEventInfo
{
    public UnityAction<T,K> actions;
}

//三泛型类

public class EventInfo<T,K,R> : IEventInfo
{
    public UnityAction<T,K,R> actions;
}

//事件中心管理模块

public class EventManager : BaseManager<EventManager>
{
    //储存事件的字典（事件中心）
    public Dictionary<string, IEventInfo> eventDic = new Dictionary<string, IEventInfo>();

    //增加事件监听-无泛型
    public void AddEventListener(string name, UnityAction action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///给该事件添加委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo).actions += action;
        }
        else
        {
            ///新建一个事件，并添加委托函数
            eventDic.Add(name, new EventInfo {actions = action});
        }

    }

    //增加事件监听-泛型
    public void AddEventListener<T>(string name, UnityAction<T> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///给该事件添加委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T>).actions += action;
        }
        else
        {
            ///新建一个事件，并添加委托函数
            eventDic.Add(name, new EventInfo<T> {actions = action});
        }

    }

    //增加事件监听-双泛型
    public void AddEventListener<T,K>(string name, UnityAction<T,K> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///给该事件添加委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T,K>).actions += action;
        }
        else
        {
            ///新建一个事件，并添加委托函数
            eventDic.Add(name, new EventInfo<T,K> {actions = action});
        }

    }

    //增加事件监听-三泛型
    public void AddEventListener<T,K,R>(string name, UnityAction<T,K,R> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///给该事件添加委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T,K,R>).actions += action;
        }
        else
        {
            ///新建一个事件，并添加委托函数
            eventDic.Add(name, new EventInfo<T,K,R> {actions = action});
        }

    }

    //销毁事件监听-无泛型
    public void RemoveEventListener(string name, UnityAction action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///销毁指定委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo).actions -= action;
        }
        //不包含相当于已经销毁
        /*else
        {
            
        }*/
    }

    //销毁事件监听-泛型
    public void RemoveEventListener<T>(string name, UnityAction<T> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///销毁指定委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T>).actions -= action;
        }
        //不包含相当于已经销毁
        /*else
        {
            
        }*/
    }

    //销毁事件监听-双泛型
    public void RemoveEventListener<T,K>(string name, UnityAction<T,K> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///销毁指定委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T,K>).actions -= action;
        }
        //不包含相当于已经销毁
        /*else
        {
            
        }*/
    }

    //销毁事件监听-三泛型
    public void RemoveEventListener<T,K,R>(string name, UnityAction<T,K,R> action)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///销毁指定委托函数

            //父类做子类，解包装
            (eventDic[name] as EventInfo<T,K,R>).actions -= action;
        }
        //不包含相当于已经销毁
        /*else
        {
            
        }*/
    }

    //触发事件监听-无泛型
    public void TriggerEventListener(string name)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///Invoke 回调无需传参

            (eventDic[name] as EventInfo).actions.Invoke();
        }
        //不包含无需触发
        /*else
        {
            
        }*/
    }

    //触发事件监听-泛型
    public void TriggerEventListener<T>(string name, T info)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///Invoke 回调需传参
            (eventDic[name] as EventInfo<T>).actions.Invoke(info);
        }
        //不包含无需触发
        /*else
        {
            
        }*/
    }

    //触发事件监听-双泛型
    public void TriggerEventListener<T,K>(string name, T info1, K info2)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///Invoke 回调需传参

            (eventDic[name] as EventInfo<T,K>).actions.Invoke(info1, info2);
        }
        //不包含无需触发
        /*else
        {
            
        }*/
    }

    //触发事件监听-三泛型
    public void TriggerEventListener<T,K,R>(string name, T info1, K info2, R info3)
    {
        //判断事件中心是否包含该事件
        if(eventDic.ContainsKey(name))
        {
            ///Invoke 回调需传参

            (eventDic[name] as EventInfo<T,K,R>).actions.Invoke(info1, info2, info3);
        }
        //不包含无需触发
        /*else
        {
            
        }*/
    }

    //事件中心清除所有事件

    public void Clear()
    {
        eventDic.Clear();
    }
}
