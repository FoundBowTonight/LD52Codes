using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : BaseManager<InputManager>
{
    private bool isStart = false;

    public InputManager()
    {
        MonoManager.GetInstance().AddUpdateListener(UpdateDo);
    }

    //开启输入检测函数
    public void SetStart(bool v)
    {
        isStart = v;
    }

    //Update中干的事
    public void UpdateDo()
    {
        if(!isStart) return;
        
        CheckKeyCode(KeyCode.Mouse0);
        CheckKeyCode(KeyCode.Space);
        CheckKeyCode(KeyCode.R);
        CheckKeyCode(KeyCode.E);
    

    }

    void CheckKeyCode(KeyCode key)
    {
        if(Input.GetKeyDown(key))
            EventManager.GetInstance().TriggerEventListener<KeyCode>("KeyIsDown", key);
        else if(Input.GetKeyUp(key))
            EventManager.GetInstance().TriggerEventListener<KeyCode>("KeyIsUp", key);
        
            

    }
}
