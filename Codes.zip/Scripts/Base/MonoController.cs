using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//这个类帮助没有继承MonoBehaviour的类实现Update, Start及协程功能

public class MonoController : MonoBehaviour
{
    private event UnityAction updateAction;
    private event UnityAction fixedUpdateAction;

    void Start()
    {
        //过场景不删除
        DontDestroyOnLoad(this);
    }

    void Update() {if(updateAction != null) updateAction();}

    void FixedUpdate() {if(fixedUpdateAction != null) fixedUpdateAction();}

    /// 添加帧更新的函数
    public void AddUpdateListener(UnityAction action) { updateAction += action;}

    public void AddFixedUpdateListener(UnityAction action) { fixedUpdateAction += action;}

    ///移除帧更新的函数
    public void RemoveUpdateListener(UnityAction action) { updateAction -= action;}

    public void RemoveFixedUpdateListener(UnityAction action) { fixedUpdateAction -= action;}

    

    
}
