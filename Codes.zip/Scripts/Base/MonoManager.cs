using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//用单例形式对controller进行封装

public class MonoManager : BaseManager<MonoManager>
{
    MonoController controller;

    //在构造函数中创建MonoController对象
    public MonoManager()
    {
        //相当于Instantiate()
        GameObject obj = new GameObject("MonoController");
        
        controller = obj.AddComponent<MonoController>();
    }

    public void AddUpdateListener(UnityAction action) => controller.AddUpdateListener(action);

    public void AddFixedUpdateListener(UnityAction action) => controller.AddFixedUpdateListener(action);

    public void RemoveUpdateListener(UnityAction action) => controller.RemoveUpdateListener(action);

    public void RemoveFixeddUpdateListener(UnityAction action) => controller.RemoveFixedUpdateListener(action);
    ///利用Contorller三种方式开启协程

    //迭代器
    public Coroutine StartCoroutine(IEnumerator routine)
    {
        return controller.StartCoroutine(routine);
    }

    //方法名两种（有无参数）
    public Coroutine StartCoroutine(string methodName)
    {
        return controller.StartCoroutine(methodName);
    }

    public Coroutine StartCoroutine(string methodName, object value = null)
    {
        return controller.StartCoroutine(methodName, value);
    }

    //延迟调用
    public void Invoke(string methodName, float delta)
    {
        controller.Invoke(methodName, delta);
    }

    //延迟调用
    public void InvokeRepeating(string methodName, float firstDelta, float delta)
    {
        controller.InvokeRepeating(methodName, firstDelta, delta);
    }
}

