using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//池子中的一列数据（一个抽屉）
public class PoolData
{
    //抽屉中，对象挂载的父节点
    public GameObject fatherObj;
    //对象容器
    public List<GameObject> poolList;

    public PoolData(GameObject obj/*该抽屉中储存的GameObject*/, GameObject poolObj/*池子实例*/)
    {
        fatherObj = new GameObject(obj.name);
        fatherObj.transform.SetParent(poolObj.transform);

        poolList = new List<GameObject>() { };
        PushObj(obj);
    }

    //往抽屉内取物品
    public GameObject GetObj()
    {
        GameObject obj = null;
        //取出第一个
        obj = poolList[0];
        poolList.RemoveAt(0);
        //断绝父子关系
        obj.transform.SetParent(null);
        //激活
        obj.SetActive(true);

        return obj;
    }

    //往抽屉内存物品
    public void PushObj(GameObject obj)
    {
        //存到抽屉中
        poolList.Add(obj);
        //设置父对象
        obj.transform.SetParent(fatherObj.transform);
        //失活
        obj.SetActive(false);
    }
}

///通用缓存池

public class PoolMgr : BaseManager<PoolMgr>
{
    Dictionary<string, PoolData> pool = new Dictionary<string, PoolData>();
    //缓存池实例
    private GameObject poolObj;
    //返回的GameObject
    public GameObject GetObj(string name, Transform parent)       
    {
        GameObject obj = null;
        if(pool.ContainsKey(name) && pool[name].poolList.Count > 0)
        {
            obj = pool[name].GetObj();
        }
        else
        {
            //缓存池中没有该物体，去目录中加载
            obj = ResMgr.GetInstance().Load<GameObject>(name);
        }
        if(parent != null)
            obj.transform.SetParent(parent);
        return obj;
    }

    public void PushObj(string name, GameObject obj)        
    {  
        //新建一个对象池实例
        if(poolObj == null) poolObj = new GameObject("Pool");

        //如果有对应抽屉
        if(pool.ContainsKey(name))
        {
            pool[name].PushObj(obj);
        }
        else
        {
            PoolData poolData = new PoolData(obj, poolObj);
            pool.Add(name, poolData);
        }
    }

    public void Clear()
    {
        pool.Clear();
        poolObj = null;
    }
}
