using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

//资源加载模块

public class ResMgr : BaseManager<ResMgr>
{
    //同步加载资源
    public T Load<T>(string name) where T : Object
    {
        T res = Resources.Load<T>(name);
        //如果是GameObject，则需实例化
        if(res is GameObject)
            return GameObject.Instantiate(res);
        else return res;
    }

    //异步加载资源包装
    //调用该函数后，物品并没有被加载，需要等n帧后才会被加载，所以不能直接返回物体，而是传给callback函数
    public void LoadAsync<T>(string name, UnityAction<T> callback) where T : Object
    {
        //开启协程
        MonoManager.GetInstance().StartCoroutine(ReallyLoadResAsync(name, callback));
    }
    //异步加载资源包
    private IEnumerator ReallyLoadResAsync<T>(string name, UnityAction<T> callback) where T : Object
    {
        ResourceRequest r = Resources.LoadAsync<T>(name);
        //挂起一帧
        yield return r;

        if(r.asset is GameObject)
            callback(GameObject.Instantiate(r.asset) as T);
        else callback(r.asset as T);
    }
}
