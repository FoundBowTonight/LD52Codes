using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    public float rotateSpeed;
    public float damage;
    public LayerMask playerLayer;
    public float timer;

    public bool preparedToExplode;
    public bool exp = true;

    private void Start() 
    {   
        EventManager.GetInstance().AddEventListener<float>("Bomb Explode", (f) =>{
            if(preparedToExplode) {GetComponent<CircleCollider2D>().enabled = false;Explode();}
        });

        EventManager.GetInstance().AddEventListener<Collider2D>("Bomb Entered", (o) =>{
            preparedToExplode = (o == GetComponent<CircleCollider2D>());
        });

        EventManager.GetInstance().AddEventListener<Collider2D>("Bomb Exit", (o) =>{
            preparedToExplode = !(o == GetComponent<CircleCollider2D>());
        });
    }

    private void FixedUpdate() 
    {
        BombRotate();
    }

    private void Update() 
    {

        if(Physics2D.OverlapCircle(GetComponent<Rigidbody2D>().position, 1.5f, playerLayer))
        {
            EventManager.GetInstance().TriggerEventListener("Player Entered");
        }
        else
        {
            EventManager.GetInstance().TriggerEventListener("Player Exit");
        }
    }

    public void BombRotate()
    {
        transform.Rotate(new Vector3(0, 0, rotateSpeed));
    }

    private void OnEnable() 
    {
        exp = true;
        GetComponent<CircleCollider2D>().enabled = true;
        Invoke("Explode", 2f);
    }

    void Explode()
    {
        if(exp)
        {
            exp = false;
            CancelInvoke("Explode");

            EventManager.GetInstance().TriggerEventListener<Transform>("Burst", transform);
            EventManager.GetInstance().TriggerEventListener<float>("Bomb Explode", damage);
            PoolMgr.GetInstance().PushObj("Bomb/Bomb", gameObject);
        }

    }

    private void OnCollisionEnter2D(Collision2D other) 
    {
        if(!other.gameObject.CompareTag("Bomb"))
            Explode();
    }

    private void OnTriggerEnter2D(Collider2D other) 
    {
        if(other.CompareTag("Enemy"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Enemy Entered", other);
        }
        if(other.CompareTag("Mine"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Mine Entered", other);
        }
        if(other.CompareTag("Bomb"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Bomb Entered", other);
        }
    }

    private void OnTriggerExit2D(Collider2D other) 
    {
        if(other.CompareTag("Enemy"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Enemy Exit", other);
        }
        if(other.CompareTag("Mine"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Mine Exit", other);
        }
        if(other.CompareTag("Bomb"))
        {
            EventManager.GetInstance().TriggerEventListener<Collider2D>("Bomb Exit", other);
        }
    }
}
