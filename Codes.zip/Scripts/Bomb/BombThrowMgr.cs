using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombThrowMgr : SingletonMono<BombThrowMgr>
{
    public float horiSpeed = 10, verSpeed = 5;

    private void Start() 
    {
        EventManager.GetInstance().AddEventListener<Transform, Vector2>("Throw", ThrowBomb);
    }

    void ThrowBomb(Transform player, Vector2 target)
    {
        Vector2 dir = (target - new Vector2(player.position.x, player.position.y)).normalized;

        GameObject bombObj = PoolMgr.GetInstance().GetObj("Bomb/Bomb", transform);
        bombObj.transform.position = player.position;

        Rigidbody2D rb = bombObj.GetComponent<Rigidbody2D>();
        //设置移动到指定点
        rb.AddForce(dir * horiSpeed);
    }

    private void OnDestroy() 
    {
        EventManager.GetInstance().RemoveEventListener<Transform, Vector2>("Throw", ThrowBomb);
    }
}
