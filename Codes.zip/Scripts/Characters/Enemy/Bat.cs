using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bat : EnemyBase
{
    
    public float chaseSpeed, idleSpeed;
    public Vector2 idleVec;
    public Animator anim;

    protected override void Start()
    {
        base.Start();
        hitBox = GetComponent<BoxCollider2D>();
        chaseBox = GetComponent<CircleCollider2D>();
        rb = GetComponent<Rigidbody2D>();

        InvokeRepeating("ChangeIdleVec", 1f, 3f);

    }
    
    private void OnEnable() 
    {
        anim.SetBool("died", false);
    }

    protected override void Update()
    {
        base.Update();
        if(state == States.Idle && idleVec.x > 0) transform.localScale = new Vector3(1, 1, 1);
        else if(state == States.Idle && idleVec.x < 0) transform.localScale = new Vector3(-1, 1, 1);
    }

    void FixedUpdate() 
    {
        switch (state)
        {
            case States.Idle:
                IdleDo();
                break;
            case States.Chasing:
                Chase(playerTransform);
                break;
        }

        if(!stats.isLive)
        {
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
            anim.SetBool("died", true);
        }
    }

    public void OnDiedDo()
    {
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        PoolMgr.GetInstance().PushObj("Characters/Bat", gameObject);
    }

    protected override void Chase(Transform player)
    {
        chaseDir = (new Vector2(player.position.x, player.position.y) - rb.position).normalized;
        rb.MovePosition(rb.position + chaseSpeed * chaseDir * Time.fixedDeltaTime);   
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            CancelInvoke("RemoveChaseState");
            state = States.Chasing;
        }
    }

    private void OnTriggerExit2D(Collider2D other) 
    {
        if(other.CompareTag("Player"))
        {
            Invoke("RemoveChaseState", 2f);
        }
    }

    void ChangeIdleVec()
    {
        idleVec = new Vector2(Random.Range(-1.1f, 1.1f), Random.Range(-1.1f, 1.1f));
    }

    void IdleDo()
    {
        rb.MovePosition(rb.position + idleVec * idleSpeed * Time.fixedDeltaTime);
    }

    private void OnCollisionEnter2D(Collision2D other) 
    {
        if(other.gameObject.CompareTag("Player"))
        {
            InvokeRepeating("Attack", 0f, 1f);
        }
    }

    private void OnCollisionExit2D(Collision2D other) {
        if(other.gameObject.CompareTag("Player"))
            CancelInvoke("Attack");
    }

    private void UniFreeze()
    {
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    void Attack()
    {
        EventManager.GetInstance().TriggerEventListener<float>("Attack Player", damage);
        rb.constraints = RigidbodyConstraints2D.FreezeAll;
        Invoke("UniFreeze", 0.2f);
    }
}
