using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour
{
    public Rigidbody2D rb;
    public enum States
    {
        Idle,
        Chasing,
    };

    public States state;

    //受伤盒//伤害盒
    public BoxCollider2D hitBox;

    public CircleCollider2D chaseBox;

    public Stats stats;
    public Vector2 chaseDir;

    public Transform playerTransform;

    public Color transparentColor;
    public Color normalColor;
    public Color hurtColor;

    public LayerMask bomb;
    public AudioSource hurtSource;

    public bool preparedToBeHurt;
    public float damage;


    protected virtual void Start() 
    {
        EventManager.GetInstance().AddEventListener<float>("Bomb Explode", OnHurt);
        EventManager.GetInstance().AddEventListener<Collider2D>("Enemy Entered", (o) => {
            if(o == hitBox)
                SetHurtStat(true);
        });
        EventManager.GetInstance().AddEventListener<Collider2D>("Enemy Exit", (o) => {
            if(o == hitBox)
                SetHurtStat(false);
        });
    }


    protected virtual void Update() 
    {
        stats.defense = Random.Range(2, 6);

        stats.SetStat();
        if(state == States.Chasing && chaseDir.x > 0) transform.localScale = new Vector3(1, 1, 1);
        else if(state == States.Chasing && chaseDir.x < 0) transform.localScale = new Vector3(-1, 1, 1);
    }

    protected virtual void Chase(Transform player)
    {

    }

    protected virtual void RemoveChaseState()
    {
        state = States.Idle;
    }

    protected virtual void OnHurt(float damage2)
    {
        if(preparedToBeHurt)
        {
            stats.health -= (damage2 - stats.defense);
            SetHurtStat(false);
            state = States.Chasing;

            hurtSource.Play();

            GetComponent<SpriteRenderer>().color = hurtColor;
            Invoke("BackToNormal", 0.3f);
        }

    }    

    void BackToNormal()
    {
        GetComponent<SpriteRenderer>().color = normalColor;
    }

    void SetHurtStat(bool b)
    {
        preparedToBeHurt = b;
    }
}
