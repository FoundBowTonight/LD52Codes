using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : SingletonMono<EnemySpawner>
{
    public GameObject enemiesObj; public Transform playerTransform;
    public List<string> enemies = new List<string>();

    public int maxNum;

    private void Start() 
    {
        InvokeRepeating("SpawnEnemy", 0.1f, 5f);
    }

    public void SpawnEnemy()
    {

        for(int i = 0; i < Random.Range(2,5);i++)
        {
            if(enemiesObj.transform.childCount < maxNum)
            {    
                GameObject obj = PoolMgr.GetInstance().GetObj("Characters/" + (enemies[Random.Range(0, enemies.Count)]), enemiesObj.transform);
                obj.transform.position = new Vector3(Random.Range(MapGenerator.GetInstance().leftX, MapGenerator.GetInstance().rightX), Random.Range(MapGenerator.GetInstance().downY, MapGenerator.GetInstance().upY));
                obj.transform.position += new Vector3(Random.Range(-1.1f, 1.1f), Random.Range(-1.1f, 1.1f), 0);
                if(obj.name == "Snake(Clone)")
                {
                    obj.GetComponent<Snake>().playerTransform = playerTransform;
                    obj.GetComponent<Snake>().damage = 15;
                }
                else
                {
                    obj.GetComponent<Bat>().playerTransform = playerTransform;
                    obj.GetComponent<Bat>().damage = 20;
                }
            }
        }
    }
}
