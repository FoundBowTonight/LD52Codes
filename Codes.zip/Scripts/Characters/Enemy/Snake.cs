using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Snake : EnemyBase
{
    public float chaseSpeed;
    public Animator anim;

    public bool tmp = true;

    protected override void Start()
    {
        base.Start();
        hitBox = GetComponent<BoxCollider2D>();
        chaseBox = GetComponent<CircleCollider2D>();
        rb = GetComponent<Rigidbody2D>();
        
        InvokeRepeating("SetChaseDir", 0.1f, 1.5f);

    }

    private void OnEnable() 
    {
        anim.SetBool("died", false);
    }

    void FixedUpdate() 
    {
        switch (state)
        {
            case States.Idle:
                break;
            case States.Chasing:
                Chase(playerTransform);
                break;
        }
        
    }

    protected override void Update()
    {
        base.Update();
        if(!stats.isLive && tmp)
        {
            rb.constraints = RigidbodyConstraints2D.FreezeAll;
            anim.SetBool("died", true);
            Invoke("OnDiedDo", 0.5f);
            tmp = false;
        }
        if(anim.GetBool("flying"))
        {
            if(stats.isLive)
                rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        }
        else  rb.constraints = RigidbodyConstraints2D.FreezeAll;
    }

    public void OnDiedDo()
    {
        tmp = true;
        rb.constraints = RigidbodyConstraints2D.FreezeAll;
        PoolMgr.GetInstance().PushObj("Characters/Snake", gameObject);
    }

    void SetChaseDir()
    {
        if(state == States.Chasing && !anim.GetBool("flying"))
        {
            chaseDir = (new Vector2(playerTransform.position.x, playerTransform.position.y) - rb.position).normalized;
            anim.SetBool("chasing", true);
            GetComponent<SpriteRenderer>().color = normalColor;
            CancelInvoke("StartFly");

            Invoke("StartFly", 0.3f);
        }
        else chaseDir = Vector2.zero;
    }

    void StartFly()
    {
        anim.SetBool("chasing", false);
        anim.SetBool("flying", true);

        Invoke("StopFly", 0.8f);
    }

    void StopFly()
    {
        Hide();
    }
    


    protected override void Chase(Transform player)
    {
        rb.MovePosition(rb.position + chaseSpeed * chaseDir * Time.fixedDeltaTime);   
    }

    private void OnTriggerEnter2D(Collider2D other) 
    {
        if(other.CompareTag("Player"))
        {
            state = States.Chasing;
        }
    }

    private void OnTriggerExit2D(Collider2D other) 
    {
        if(other.CompareTag("Player"))
        {
            state = States.Idle;
        }
    }

    private void OnCollisionEnter2D(Collision2D other) 
    {
        if(other.gameObject.CompareTag("Player") && stats.isLive)
        {
            InvokeRepeating("Attack", 0f, 1f);
        }
    }

    private void OnCollisionExit2D(Collision2D other) {
        if(other.gameObject.CompareTag("Player"))
        {
            CancelInvoke("Attack");
        }
    }

    public void Hide()
    {
        anim.SetBool("flying", false);
        anim.SetBool("hiding", true);

        Invoke("ReallyHide", 0.25f);
    }

    public void ReallyHide()
    {
        anim.SetBool("hiding", false);
        GetComponent<SpriteRenderer>().color = transparentColor;
    }

    void Attack()
    {
        EventManager.GetInstance().TriggerEventListener<float>("Attack Player", damage);
    }
}
