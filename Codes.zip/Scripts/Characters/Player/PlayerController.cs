using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rb;
    Animator anim;
    public CircleCollider2D coll;
    public float speed;

    private Vector2 movement;

    public Stats stats;
    public float money;
    public int bombNum;
    public int randomSeedNum;

    public bool tmp = true;

    public AudioSource hurtSource;
    public AudioSource pickSource;

    public bool preparedToBeHurt;

    public Color normalColor;
    public Color hurtColor;
    public Color minusCoinColor, addCoinColor;

    public Vector2 rectForBlood, rectForCoin;
    
    void Start()
    {

        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        EventManager.GetInstance().AddEventListener("Player Entered", () => {
            preparedToBeHurt = true;
        });
        EventManager.GetInstance().AddEventListener("Player Exit", () => {
            preparedToBeHurt = false;
        });
        EventManager.GetInstance().AddEventListener<float>("Bomb Explode", (d) => {
            if(!stats.isGod && stats.isLive)
            {
                if(preparedToBeHurt)
                {
                    stats.health -= (d - stats.defense);
                    preparedToBeHurt = false;

                    hurtSource.Play();

                    stats.isGod = true;
                    Invoke("CancelGod", 0.5f);

                    GetComponent<SpriteRenderer>().color = hurtColor;

                    EventManager.GetInstance().TriggerEventListener<Vector2, Color, float>("CallText",rectForBlood , hurtColor, stats.defense - d);
                    EventManager.GetInstance().TriggerEventListener<float>("PlayerHealthChanged", stats.health);

                    Invoke("BackToNormal", 0.3f);
                }
            }
        });

        EventManager.GetInstance().AddEventListener<float>("Harvest", (v) => {
            money += v;randomSeedNum += Random.Range(1, 4);
            EventManager.GetInstance().TriggerEventListener<Vector2, Color, float>("CallText", rectForCoin , addCoinColor, v);
            pickSource.Play();
            EventManager.GetInstance().TriggerEventListener<float>("CoinNumChanged", money);
            EventManager.GetInstance().TriggerEventListener<int>("SeedNumChanged", randomSeedNum);
        });
        EventManager.GetInstance().AddEventListener<KeyCode>("KeyIsDown", OnKeyIsDown);
        EventManager.GetInstance().AddEventListener<float>("Attack Player", (d) => {
            if(!stats.isGod && stats.isLive)
            {
                stats.health -= (d - stats.defense);
                hurtSource.Play();
                stats.isGod = true;
                Invoke("CancelGod", 0.5f);
                
                GetComponent<SpriteRenderer>().color = hurtColor;
                Invoke("BackToNormal", 0.3f);

                EventManager.GetInstance().TriggerEventListener<Vector2, Color, float>("CallText",rectForBlood , hurtColor, stats.defense - d);
            }
            EventManager.GetInstance().TriggerEventListener<float>("PlayerHealthChanged", stats.health);
        });
        EventManager.GetInstance().TriggerEventListener<int>("BombNumChanged", bombNum);
        EventManager.GetInstance().TriggerEventListener<int>("SeedNumChanged", randomSeedNum);

        OnRebirth();
    }

    void BackToNormal()
    {
        GetComponent<SpriteRenderer>().color = normalColor;
    }

    public void OnRebirth() 
    {
        stats.isGod = true;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        GetComponent<CircleCollider2D>().enabled = true;
        InputManager.GetInstance()?.SetStart(true);
        EventManager.GetInstance()?.TriggerEventListener<int>("BombNumChanged", bombNum);
        EventManager.GetInstance()?.TriggerEventListener<int>("SeedNumChanged", randomSeedNum);
        EventManager.GetInstance()?.TriggerEventListener<float>("PlayerHealthChanged", stats.health);
        EventManager.GetInstance()?.TriggerEventListener<float>("CoinNumChanged", money);
        Invoke("CancelGod", 0.5f);
    }

    private void OnDisable() 
    {
        GetComponent<CircleCollider2D>().enabled = false;
        InputManager.GetInstance().SetStart(false);
    }

    void SwitchAnim()
    {
        if(movement.x != 0 && stats.isLive)
        {
            transform.localScale = new Vector3(movement.x, 1, 1);
        }

        if(!(stats.isLive) && tmp)
        {
            EventManager.GetInstance().TriggerEventListener("PlayerDied");
            InputManager.GetInstance().SetStart(false);
            tmp = false;
        }

        if(stats.isLive) anim.SetFloat("running", movement.magnitude);
        anim.SetBool("died", !(stats.isLive));
    }

    
    void Update()
    {
        stats.defense = Random.Range(2, 6);

        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        stats.SetStat();

        if(!stats.isLive)
            rb.constraints = RigidbodyConstraints2D.FreezeAll;

        SwitchAnim();

    }

    void FixedUpdate() 
    {
        if(stats.isLive)
        {
            if(movement.magnitude > 1.4)
            {
                rb.MovePosition(rb.position + speed * Time.fixedDeltaTime / 1.4f * movement);
            }
            else 
            {
                rb.MovePosition(rb.position + speed * Time.fixedDeltaTime * movement);
            }
        }
    }

    void OnKeyIsDown(KeyCode key)
    {
        switch(key)
        {
            case KeyCode.Mouse0:
                if(bombNum > 0 && !PlayTimeUI.GetInstance().mouseIsOnUI)
                {
                    anim.SetBool("throwing", true);
                    rb.constraints = RigidbodyConstraints2D.FreezeAll;
                    bombNum--;
                    Invoke("AfterThrowDO", 0.2f);
                }
                break;
            case KeyCode.Space:
                if(randomSeedNum > 0)
                {
                    EventManager.GetInstance().TriggerEventListener<Transform>("Plant", transform);
                    randomSeedNum -- ;
                    EventManager.GetInstance().TriggerEventListener<int>("SeedNumChanged", randomSeedNum);
                }
                break;
            case KeyCode.R:
                BuyBomb();
                break;
            case KeyCode.E:
                BuySeed();
                break;
        }
    }

    void AfterThrowDO()
    {
        anim.SetBool("throwing", false);

        Vector3 targetVec3 = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 target = new Vector2(targetVec3.x, targetVec3.y);
        EventManager.GetInstance().TriggerEventListener<Transform, Vector2>("Throw", transform, target);
        EventManager.GetInstance().TriggerEventListener<int>("BombNumChanged", bombNum);
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        
    }

    void CancelGod()
    {
        stats.isGod = false;
    }

    public void BuyBomb()
    {
        if(money >= GameMgr.GetInstance().bombPrice)
        {
            money -= GameMgr.GetInstance().bombPrice;
            EventManager.GetInstance().TriggerEventListener<Vector2, Color, float>("CallText", rectForCoin , minusCoinColor, -GameMgr.GetInstance().bombPrice);
            bombNum ++;
            EventManager.GetInstance().TriggerEventListener<int>("BombNumChanged", bombNum);
            EventManager.GetInstance()?.TriggerEventListener<float>("CoinNumChanged", money);
        }
        
    }

    public void BuySeed()
    {
        if(money >= GameMgr.GetInstance().seedPrice)
        {
            money -= GameMgr.GetInstance().seedPrice;
            EventManager.GetInstance().TriggerEventListener<Vector2, Color, float>("CallText", rectForCoin , minusCoinColor, -GameMgr.GetInstance().seedPrice);
            randomSeedNum ++;
            EventManager.GetInstance().TriggerEventListener<int>("SeedNumChanged", randomSeedNum);
            EventManager.GetInstance()?.TriggerEventListener<float>("CoinNumChanged", money);
        }
    }

    private void OnDestroy()
    {
        EventManager.GetInstance().RemoveEventListener<float>("Harvest", (v) => {
            money += v;randomSeedNum += Random.Range(1, 4);
            EventManager.GetInstance().TriggerEventListener<int>("SeedNumChanged", randomSeedNum);
        });
        EventManager.GetInstance().RemoveEventListener<KeyCode>("KeyIsDown", OnKeyIsDown);
        EventManager.GetInstance().RemoveEventListener<float>("Attack Player", (d) => {
            if(!stats.isGod)
                stats.health -= (d - stats.defense);
            else stats.isGod = true;
            EventManager.GetInstance().TriggerEventListener<float>("PlayerHealthChanged", stats.health);
            Invoke("CancelGod", 0.5f);
        });
    }

}
