using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Stats
{
    public float health, maxHealth;
    public float defense;
    public bool isGod, isLive;

    public void SetStat()
    {
        isLive = (health > 0);
        if(!isLive)
            health = 0;
    }

}
