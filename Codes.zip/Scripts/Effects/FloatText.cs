using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FloatText : MonoBehaviour
{
    public Text numText;

    public float verForce;
    public float horiForce;
    
    private void OnEnable() 
    {
        GetComponent<Rigidbody2D>().AddForce(verForce * Vector2.up);
        GetComponent<Rigidbody2D>().AddForce(horiForce * new Vector2(Random.Range(-1.1f, 1.1f), Random.Range(0f, 1.1f)));
        Invoke("Push", Random.Range(1f, 2f));
    } 

    void Push()
    {
        PoolMgr.GetInstance().PushObj("Effects/FloatText", gameObject);
    }
}
