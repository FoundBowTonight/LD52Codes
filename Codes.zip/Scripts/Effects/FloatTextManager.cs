using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FloatTextManager : SingletonMono<FloatTextManager>
{
    public Transform textParent;
    
    private void Start() 
    {
        EventManager.GetInstance().AddEventListener<Vector2, Color, float>("CallText", OnCallDo);
    }

    public void OnCallDo(Vector2 anchoredPosition, Color textColor, float num)
    {
        GameObject obj = PoolMgr.GetInstance().GetObj("Effects/TextFloat", textParent);
        obj.GetComponent<FloatText>().numText.color = textColor;
        RectTransform r = obj.transform as RectTransform;
        r.anchoredPosition = anchoredPosition;

        if(num > 0)
            obj.GetComponent<FloatText>().numText.text = "+" + num.ToString();
        else if(num < 0)
            obj.GetComponent<FloatText>().numText.text = num.ToString();

    }
}
