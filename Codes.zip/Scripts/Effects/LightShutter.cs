using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class LightShutter : MonoBehaviour
{
    public UnityEngine.Rendering.Universal.Light2D tarLight;

    private void OnEnable() 
    {
        Invoke("ShutLight", 2.5f);
    }

    private void OnDisable() {
        
    }

    public void ShutLight()
    {
        gameObject.SetActive(false);
    }
}
