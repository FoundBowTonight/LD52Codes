using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ParticleSet
{
    public string name;
    public List<string> effects = new List<string>();
}

public class ParticleManager : SingletonMono<ParticleManager>
{
    public ParticleSet burst;
    public AudioSource burstAudio;
    List<GameObject> loopingPars = new List<GameObject>();

    void Start()
    {
        EventManager.GetInstance().AddEventListener<Transform>("Burst", (t) => {
            burstAudio.Play();
            for(int i = 0; i < burst.effects.Count; i++)
            {
                GameObject obj = PoolMgr.GetInstance().GetObj(burst.effects[i], transform);
                loopingPars.Add(obj);
                obj.transform.position = t.position;
            }
        });
    }

    private void Update() 
    {
        for(int i = 0; i < loopingPars.Count; i++)
        {
            if(!loopingPars[i].GetComponent<ParticleSystem>().isPlaying)
            {
                PoolMgr.GetInstance().PushObj("Particles/" + (loopingPars[i].name).Replace("(Clone)", ""), loopingPars[i]);
                loopingPars.RemoveAt(i);
            }
        }
    }
}
