using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Cinemachine;

public class GameMgr : SingletonMono<GameMgr>
{
    public GameObject player;
    public int bombPrice;
    public int seedPrice;

    public int requireTime;
    public int leftTime;

    public float requireMoney; 

    private void Start() 
    {
        EventManager.GetInstance().AddEventListener("PlayerDied", () => {Invoke("PlayerRebirth", 3f);});
        EventManager.GetInstance().AddEventListener("TimeIsUp", () => {
            if(player.GetComponent<PlayerController>().money >= requireMoney)
            {
                SceneManager.LoadScene("Win");
            }
            else
            {
                SceneManager.LoadScene("Fail");
            }
        });


        InvokeRepeating("ReadTime", 1f, 1f);
        leftTime = requireTime;
    }

    public void PlayerRebirth()
    {
        player.GetComponent<PlayerController>().stats.health = player.GetComponent<PlayerController>().stats.maxHealth;
        player.GetComponent<PlayerController>().stats.isLive = true;
        player.GetComponent<PlayerController>().money = 25;
        player.GetComponent<PlayerController>().randomSeedNum = 0;
        player.GetComponent<PlayerController>().bombNum = 5;
        player.GetComponent<PlayerController>().tmp = true;
        player.GetComponent<PlayerController>().OnRebirth();
        player.transform.position = Vector3.zero;

        player.SetActive(true);

        InputManager.GetInstance().SetStart(true);
    }

    public void ReadTime()
    {
        if(leftTime > 0)
        {
            leftTime--;
            //几分几秒
            EventManager.GetInstance().TriggerEventListener<int, int>("ReadingTime", leftTime/60, leftTime%60);
        }
        else
        {
            EventManager.GetInstance().TriggerEventListener("TimeIsUp");
        }
    }

    private void OnDestroy() 
    {
        EventManager.GetInstance().RemoveEventListener("PlayerDied", () => {Invoke("PlayerRebirth", 3f);});
        EventManager.GetInstance().RemoveEventListener("TimeIsUp", () => {
            if(player.GetComponent<PlayerController>().money >= requireMoney)
            {
                SceneManager.LoadScene("Win");
            }
            else
            {
                SceneManager.LoadScene("Fail");
            }
        });
    }
}
