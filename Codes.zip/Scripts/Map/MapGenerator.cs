using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class MapGenerator : SingletonMono<MapGenerator>
{
    public TileBase rock;
    public Tilemap back, edge;

    public int leftX, rightX, upY, downY;

    private void Start() 
    {
        GenerateMap();
    }

    public void GenerateMap()
    {
        for(int i = leftX; i < rightX; i++)
        {
            for(int j = downY; j < upY; j++)
            {
                back.SetTile(new Vector3Int(i, j, 0), rock);
            }
        }

        for(int i = leftX; i < rightX; i++)
        {
            edge.SetTile(new Vector3Int(i, upY, 0), rock);
            edge.SetTile(new Vector3Int(i, downY - 1, 0), rock);
        }

        for(int i = downY; i < upY; i++)
        {
            edge.SetTile(new Vector3Int(leftX - 1, i, 0), rock);
            edge.SetTile(new Vector3Int(rightX, i, 0), rock);
        }
    }
}
