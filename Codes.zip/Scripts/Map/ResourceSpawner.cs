using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResourceSpawner : SingletonMono<ResourceSpawner>
{
    //权重列表
    public List<Item> mines = new List<Item>();
    public float spawnValue;
    public int leftX = -50, rightX = 50, upY = 50, downY = -50;

    public GameObject minesObj;

    private void Start() 
    {
        EventManager.GetInstance().AddEventListener<Transform>("Plant", Spawn);
        InitSpawn();
    }

    public void InitSpawn()
    {
        for(int i = leftX; i < rightX; i++)
        {
            for(int j = downY; j < upY; j++)
            {
                if(Random.Range(0f, 1.1f) < spawnValue)
                {
                    GameObject obj = PoolMgr.GetInstance().GetObj("Mines/" + (mines[Random.Range(0, mines.Count)].itemName), minesObj.transform);
                    obj.transform.position = new Vector3(i, j, 0);
                    obj.transform.position += new Vector3(Random.Range(-1.1f, 1.1f), Random.Range(-1.1f, 1.1f), 0);
                }
            }
        }
    }

    public void Spawn(Transform transform)
    {
        GameObject obj = PoolMgr.GetInstance().GetObj("Mines/" + (mines[Random.Range(0, mines.Count)].itemName), minesObj.transform);
        obj.transform.position = transform.position;
        obj.transform.position += new Vector3(Random.Range(-1.1f, 1.1f), Random.Range(-1.1f, 1.1f), 0);
    }
}
