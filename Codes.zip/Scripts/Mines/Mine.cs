using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mine : MonoBehaviour
{
    public Item mine;

    public float growSpeed;
    public float growValue;
    public float harvestValue;

    public bool isHarvest;
    public bool preparedToBeDestroy;

    public Color harvestColor;

    public LayerMask bomb;
    public BoxCollider2D hitBox;

    void Start() 
    {
        InvokeRepeating("Grow", 1f, 1f);
        EventManager.GetInstance().AddEventListener<float>("Bomb Explode", Destroy);
        
        EventManager.GetInstance().AddEventListener<Collider2D>("Mine Entered", (o) => {
            if(o == hitBox)
                SetHurtStat(true);
        });
        EventManager.GetInstance().AddEventListener<Collider2D>("Mine Exit", (o) => {
            if(o == hitBox)
                SetHurtStat(false);
        });
    }

    void Update() 
    {
        DisplayGrowValue();

    }

    void SetHurtStat(bool b)
    {
        preparedToBeDestroy = b;
    }


    public void Grow()
    {
        growValue += growSpeed;
        if(growValue >= harvestValue)
        {
            isHarvest = true;
            CancelInvoke("Grow");
            GetComponent<SpriteRenderer>().color = harvestColor;
        }
    }

    public void DisplayGrowValue()
    {
        transform.localScale = new Vector3(growValue/harvestValue, growValue/harvestValue, 1);
        GetComponent<BoxCollider2D>().size = new Vector2(2.5f,2.5f) * growValue/harvestValue;
    }
    //o没用
    public void Destroy(float o)
    {
        if(preparedToBeDestroy)
        {
            if(isHarvest)
            {
                EventManager.GetInstance().TriggerEventListener<float>("Harvest", mine.value);
            }
            isHarvest = false;

            PoolMgr.GetInstance().PushObj("Mines" + mine.itemName, gameObject);
        }
    }

    private void OnDestroy() 
    {
        EventManager.GetInstance().RemoveEventListener<float>("Bomb Explode", Destroy);
    }
}
