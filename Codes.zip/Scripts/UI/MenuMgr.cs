using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuMgr : SingletonMono<MenuMgr>
{
    public void Play()
    {
        OnPlayDo();
        SceneManager.LoadScene("World");
    }

    public void OnPlayDo()
    {
        PoolMgr.GetInstance().Clear();
        EventManager.GetInstance().Clear();
    }

    public void EnterRules()
    {
        SceneManager.LoadScene("Rules");
    }

    public void OnQuit()
    {
        Application.Quit();
    }

}
