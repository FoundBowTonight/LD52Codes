using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class PlayTimeUI : SingletonMono<PlayTimeUI>
{
    public Slider slider;
    public Text bombNum;
    public Text seedNum;
    public Text time;
    public Text coinNum;

    public bool mouseIsOnUI;

    private void Start() 
    {
        EventManager.GetInstance().AddEventListener<float>("PlayerHealthChanged", (h) => {slider.value = h/100;});
        EventManager.GetInstance().AddEventListener("PlayerDied", () => {slider.value = 0;});

        EventManager.GetInstance().AddEventListener<int, int>("ReadingTime", ReadTime);
        EventManager.GetInstance().AddEventListener<float>("CoinNumChanged", (o) => {coinNum.text = o.ToString();});


        EventManager.GetInstance().AddEventListener<int>("BombNumChanged", DisplayBombNum);
        EventManager.GetInstance().AddEventListener<int>("SeedNumChanged", DisplaySeedNum);
    }

    private void Update() 
    {
        mouseIsOnUI = EventSystem.current.IsPointerOverGameObject();
    }

    public void Pause()
    {
        Time.timeScale = 0;
    }

    public void Resume()
    {
        Time.timeScale = 1;
    }

    public void Restart()
    {
        PoolMgr.GetInstance().Clear();
        EventManager.GetInstance().Clear();
        Resume();
        SceneManager.LoadScene("World");
    }

    public void Quit()
    {
        PoolMgr.GetInstance().Clear();
        EventManager.GetInstance().Clear();
        Resume();
        SceneManager.LoadScene("Menu");
    }

    public void DisplayBombNum(int n)
    {
        bombNum.text = n.ToString();
    }

    public void DisplaySeedNum(int n)
    {
        seedNum.text = n.ToString();
    }

    private void OnDestroy() 
    {
        EventManager.GetInstance().RemoveEventListener<float>("PlayerHealthChanged", (h) => {slider.value = h/100;});
        EventManager.GetInstance().RemoveEventListener("PlayerDied", () => {slider.value = 0;});


        EventManager.GetInstance().RemoveEventListener<int>("BombNumChanged", DisplayBombNum);
        EventManager.GetInstance().RemoveEventListener<int>("SeedNumChanged", DisplaySeedNum);
    }

    public void ReadTime(int min, int second)
    {
        time.text = (min.ToString() + " min " + second.ToString() + " s");
    }

}
