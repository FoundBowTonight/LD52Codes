using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinFailMgr : MonoBehaviour
{
    public void Restart()
    {
        PoolMgr.GetInstance().Clear();
        EventManager.GetInstance().Clear();
        SceneManager.LoadScene("World");
    }

    public void Quit()
    {
        PoolMgr.GetInstance().Clear();
        EventManager.GetInstance().Clear();
        SceneManager.LoadScene("Menu");
    }
}
